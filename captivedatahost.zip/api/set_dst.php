<?php
// Salva o site de destino pós-anúncio (dst do hotspot) por roteador.
// Isolamento (igual ao upload de anúncio):
//   - comprador comum: destino é SEMPRE o próprio roteador;
//   - admin: o roteador é o do cliente da tela de leads aberta (cliente_id),
//            resolvido no servidor — nunca um roteador arbitrário do formulário.
require_once __DIR__ . '/../inc/auth.php';
require_once __DIR__ . '/../inc/util.php';

$c = exigir_login();

// O roteador do POST é VALIDADO contra a lista da conta (cliente) ou do
// cliente aberto (admin) — nunca um identity arbitrário do formulário.
if ((int) $c['is_admin'] === 1) {
    $cid      = (int) ($_POST['cliente_id'] ?? 0);
    $roteador = (string) roteador_escolhido(roteadores_conta($cid), $_POST['roteador'] ?? null);
    $voltar   = '../admin_leads.php?id=' . $cid . ($roteador !== '' ? '&r=' . rawurlencode($roteador) : '');
} else {
    $roteador = (string) roteador_escolhido(roteadores_conta((int) $c['id']), $_POST['roteador'] ?? null);
    $voltar   = '../painel.php' . ($roteador !== '' ? '?r=' . rawurlencode($roteador) : '');
}

function voltar_msg(string $to, string $key, string $msg): void
{
    $sep = (strpos($to, '?') === false) ? '?' : '&';
    header('Location: ' . $to . $sep . $key . '=' . rawurlencode($msg));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    voltar_msg($voltar, 'dst_erro', 'Requisição inválida.');
}
if (!csrf_valido($_POST['csrf'] ?? '')) {
    voltar_msg($voltar, 'dst_erro', 'Sessão expirada. Recarregue e tente de novo.');
}
if ($roteador === '') {
    voltar_msg($voltar, 'dst_erro', 'Este cliente não tem roteador vinculado.');
}

$url = trim((string) ($_POST['dst'] ?? ''));
if ($url === '') {
    voltar_msg($voltar, 'dst_erro', 'Informe a URL do site de destino.');
}
if (strlen($url) > 2048) {
    voltar_msg($voltar, 'dst_erro', 'URL muito longa.');
}
// Sem esquema → assume https://.
if (!preg_match('~^[a-z][a-z0-9+.\-]*://~i', $url)) {
    $url = 'https://' . $url;
}
$parts = parse_url($url);
$scheme = isset($parts['scheme']) ? strtolower($parts['scheme']) : '';
if ($parts === false || empty($parts['host']) || !in_array($scheme, ['http', 'https'], true)) {
    voltar_msg($voltar, 'dst_erro', 'URL inválida. Use um endereço http:// ou https://');
}
if (!filter_var($url, FILTER_VALIDATE_URL)) {
    voltar_msg($voltar, 'dst_erro', 'URL inválida.');
}

// Link de PERFIL do Instagram ganha ?ig_mid=<uuid>&utm_source=igweb: com esses
// parâmetros o Instagram serve a PÁGINA WEB do perfil (aviso fechável + botão
// "Abrir aplicativo") em vez de forçar o redirect instagram:// — que o CNA do
// iPhone bloqueia com "Erro ao Abrir a Página".
if (preg_match('~^https?://(www\.)?instagram\.com/([A-Za-z0-9._]{1,30})/?(\?.*)?$~i', $url, $m)
    && !in_array(strtolower($m[2]), ['p', 'reel', 'reels', 'stories', 'explore', 'accounts'], true)) {
    $hex = strtoupper(bin2hex(random_bytes(16)));
    $mid = substr($hex, 0, 8) . '-' . substr($hex, 8, 4) . '-' . substr($hex, 12, 4) . '-'
         . substr($hex, 16, 4) . '-' . substr($hex, 20, 12);
    $url = 'https://www.instagram.com/' . $m[2] . '/?ig_mid=' . $mid . '&utm_source=igweb';
}

$dir = ads_dir();
if (!is_dir($dir)) {
    @mkdir($dir, 0755, true);
}
if (@file_put_contents(dst_file($roteador), $url) === false) {
    voltar_msg($voltar, 'dst_erro', 'Não foi possível salvar. Verifique a pasta de dados.');
}
@chmod(dst_file($roteador), 0644);

voltar_msg($voltar, 'dst_ok', 'Site de destino atualizado! Já vale para as próximas conexões.');
